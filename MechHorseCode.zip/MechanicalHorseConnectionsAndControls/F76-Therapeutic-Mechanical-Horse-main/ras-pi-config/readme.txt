On Raspberry Pi:
sudo apt-get install hostapd
sudo apt-get install dnsmasq

Use Configs provide to overwrite:

/etc/dhcpcd.conf
/etc/dnsmasq.conf
/etc/hostapd/hostapd.conf

sudo reboot


PASSWORDS:
Raspberry Pi Password: 1234
VNC Password for LAN access: 12345678910