# F76-Therapeutic-Mechanical-Horse
Repo for for 2022 ME Senior Project team F76-Therapeutic-Mechanical-Horse
