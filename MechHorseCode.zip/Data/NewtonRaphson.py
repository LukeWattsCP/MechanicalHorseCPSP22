import csv
import math
import pandas as pd
import numpy as np

# measured constants for kinetic model
r1 = 2.5
r2 = -2.5
la1 = 40
la2 = 40

lb = 17.375
le = 8.5
lc = 3
ld = 36.25
lp = 15

ll = 24.25
lh = 10
lw = 6.75

# Function for predicting second motor angle from guessed first motor angle and orientation data using kinetic model
def predict_angles(dp, theta1, index):
    yaw = math.radians(dp.iloc[0]) # i hat
    roll = math.radians(dp.iloc[1]) # k hat
    pitch = math.radians(dp.iloc[2]) # j hat

    lp_i = lp * math.cos(yaw)
    lp_j = lp * math.cos(pitch)
    lp_k = lp * math.cos(roll)

    frame_i = -1 * (-1*lp_i + lb)
    frame_j = lp_j - lc + ld
    frame_k = -1 * (lp_k + le) # for accuracy tests

    arm_i = 2*(ll*math.sin(pitch) - ll*math.sin(yaw)) - 2*lh*math.cos(pitch) - 2*lw*math.cos(yaw) 
    arm_j = (2*ll*math.cos(pitch) - 2*(lh*math.sin(pitch) + lh*math.sin(roll))) + r1*math.sin(theta1) 
    
    r2_j = frame_j - arm_j
    theta2 = math.asin(r2_j/r2) # calculate second angle
    # theta2 = math.asin(((r1*math.sin(theta1) - 2*ll*math.cos(pitch) - 2*((lh*math.sin(pitch)) + (lh*math.sin(roll))) + (lp*math.cos(pitch)) - lc + ld) / (-1*r2)))
    arm_k = r1*math.cos(theta1) - r2*math.cos(theta2) + 2*ll*math.cos(yaw) + 2*lh*math.cos(roll) - 2*lw*math.sin(yaw) # for accuracy tests

     
    return theta1, theta2, frame_k, arm_k

# modifying the guess for the first angle using the derivative of the kinetic model
def modify_pred_theta(theta1, theta2, arm_k, dp):
    yaw = math.radians(dp.iloc[0]) # i hat
    roll = math.radians(dp.iloc[1]) # k hat
    pitch = math.radians(dp.iloc[2]) # j hat
    term = ((r1*math.sin(theta1) - 2*ll*math.cos(pitch) - 2*((lh*math.sin(pitch)) + (lh*math.sin(roll))) + (lp*math.cos(pitch)) - lc + ld) / (-1*r2))
    numerator = (r1*math.cos(theta1))*term
    denominator = math.sqrt(1 - (term)**2)
    deriv1_arm_k = -1*r1*math.sin(theta1) - (numerator / denominator)
    return (theta1 - (arm_k / deriv1_arm_k))




def main():
    pred_angles = np.zeros((5000,2))
    # yaw, roll, pitch
    df = pd.read_csv('horseOriSmoothTrimAdj.csv', header = None)

    prev_theta1 = 0

    for index, row in df.iterrows():
        while(1):
            try:
                theta1, theta2, frame_k, arm_k = predict_angles(row, prev_theta1, index) # find motor angle pair
            except:
                # print(row)
                pred_angles[index,0] = 9001
                pred_angles[index,1] = 9001 #save invalid points to see where errors occurred
                prev_theta1 = theta1
                break

            arm_k_error = math.fabs(((frame_k - arm_k) / frame_k) * 100) # check for error in angles

            if(arm_k_error < 10): # save points if error is minimal
                pred_angles[index,0] = math.degrees(theta1)
                pred_angles[index,1] = math.degrees(theta2)
                prev_theta1 = theta1
                break #next iteration
            else:
                prev_theta1 = modify_pred_theta(theta1, theta2, arm_k, row)%(3.14159265359) # recalculate guessed first motor angle for next recalculation
        prev_theta1 = theta1 # set theta1 to previous for next iteration
    
    with open("predicted_motor_angles.csv","w+") as my_csv: # save calculated angles to csv
        csvWriter = csv.writer(my_csv,delimiter=',')
        csvWriter.writerows(pred_angles)
    return

if __name__ == "__main__":
    main()

