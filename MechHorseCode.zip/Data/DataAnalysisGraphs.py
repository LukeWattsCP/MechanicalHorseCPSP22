import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def cos_sim(x, df_live):
    rm = x.to_numpy()
    rl = (df_live.iloc[x.name]).to_numpy()
    numerator = np.dot(rl, rm)
    denominator = (np.linalg.norm(rl)*np.linalg.norm(rm))
    return (numerator / denominator)

def ori_sim(x, df_live, ori):
    rm = x.to_numpy()
    rl = (df_live.iloc[x.name]).to_numpy()
    
    if ori == 'yaw':
        return (abs(rm[0] - rl[0]))
    elif ori == 'roll':
        return (abs(rm[1] - rl[1]))
    elif ori == 'pitch':
        return (abs(rm[2] - rl[2]))


def main():
    df_mech = pd.read_csv('finaldata\MechanicalSmoothTrimAvg.csv', header = None)
    df_live = pd.read_csv('trimmed\horseOriSmoothTrimAvg.csv', header = None)

    plt.plot(df_live.iloc[:][0].index, df_live.iloc[:][0].values)
    plt.title("Live Horse Yaw vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Yaw (degrees)")
    plt.show()
    plt.clf()

    plt.plot(df_mech.iloc[:][0].index, df_mech.iloc[:][0].values)
    plt.title("Mech. Horse Yaw vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Yaw (degrees)")
    plt.show()
    plt.clf()

    scores = (df_mech.apply(lambda x: ori_sim(x, df_live, 'yaw'), axis = 1)).to_numpy()
    plt.plot(np.arange(0,5000), scores)
    plt.title("Diff. in Yaw (Mech - Live) vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Yaw Diff (degrees)")
    plt.show()
    plt.clf()
    
    print("Yaw Diff min: " + str(np.min(scores)) + " at index " + str(np.argmin(scores)))
    print("Yaw Diff max: " + str(np.max(scores)) + " at index " + str(np.argmax(scores)))
    print("Yaw Diff avg: " + str(np.average(scores)))



    plt.plot(df_live.iloc[:][1].index, df_live.iloc[:][1].values)
    plt.title("Live Horse Roll vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Roll (degrees)")
    plt.show()
    plt.clf()

    plt.plot(df_mech.iloc[:][1].index, df_mech.iloc[:][1].values)
    plt.title("Mech. Horse Roll vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Roll (degrees)")
    plt.show()
    plt.clf()

    scores = (df_mech.apply(lambda x: ori_sim(x, df_live, 'roll'), axis = 1)).to_numpy()
    plt.plot(np.arange(0,5000), scores)
    plt.title("Diff. in Roll (Mech - Live) vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Roll Diff (degrees)")
    plt.show()
    plt.clf()

    print("Roll Diff min: " + str(np.min(scores)) + " at index " + str(np.argmin(scores)))
    print("Roll Diff max: " + str(np.max(scores)) + " at index " + str(np.argmax(scores)))
    print("Roll Diff avg: " + str(np.average(scores)))


    plt.plot(df_live.iloc[:][2].index, df_live.iloc[:][2].values)
    plt.title("Live Horse Pitch vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Pitch (degrees)")
    plt.show()
    plt.clf()

    plt.plot(df_mech.iloc[:][2].index, df_mech.iloc[:][2].values)
    plt.title("Mech. Horse Pitch vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Pitch (degrees)")
    plt.show()
    plt.clf()

    scores = (df_mech.apply(lambda x: ori_sim(x, df_live, 'pitch'), axis = 1)).to_numpy()
    plt.plot(np.arange(0,5000), scores)
    plt.title("Diff. in Pitch (Mech - Live) vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Pitch Diff (degrees)")
    plt.show()
    plt.clf()

    print("Pitch Diff min: " + str(np.min(scores)) + " at index " + str(np.argmin(scores)))
    print("Pitch Diff max: " + str(np.max(scores)) + " at index " + str(np.argmax(scores)))
    print("Pitch Diff avg: " + str(np.average(scores)))


    scores = (df_mech.apply(lambda x: cos_sim(x, df_live), axis = 1)).to_numpy()

    plt.plot(np.arange(0,5000), scores)
    plt.title("Cos Sim (Mech : Live) vs Time")
    plt.xlabel("Time (centiseconds)")
    plt.ylabel("Cos Sim (degrees)")
    plt.show()
    plt.clf()
    print("Cos Sim min: " + str(np.min(scores)) + " at index " + str(np.argmin(scores)))
    print("Cos Sim max: " + str(np.max(scores)) + " at index " + str(np.argmax(scores)))
    print("Cos Sim avg: " + str(np.average(scores)))

    print("\nend")


if __name__ == "__main__":
    main()
