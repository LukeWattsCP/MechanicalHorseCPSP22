import pandas as pd

rAcc = pd.read_csv(r"C:\Users\lukea\Documents\srproj\RiderAccelerationSmooth.csv")
rAcc = rAcc.drop(rAcc.index[10000:])
rAcc = rAcc.drop(rAcc.index[:5000])
print(rAcc.size)

# rAcc.to_csv("riderAccSmoothTrim.csv", header=False, index=False)


rOri = pd.read_csv(r"C:\Users\lukea\Documents\srproj\RiderOrientationSmooth.csv")
rOri = rOri.drop(rOri.index[10000:])
rOri = rOri.drop(rOri.index[:5000])
print(rOri.size)

# rOri.to_csv("riderOriSmoothTrim.csv", header=False, index=False)


hAcc = pd.read_csv(r"C:\Users\lukea\Documents\srproj\HorseAccelerationSmooth.csv")
hAcc = hAcc.drop(hAcc.index[10000:])
hAcc = hAcc.drop(hAcc.index[:5000])
print(rAcc.size)

# hAcc.to_csv("horseAccSmoothTrim.csv", header=False, index=False)


hOri = pd.read_csv(r"C:\Users\lukea\Documents\srproj\HorseOrientationSmooth.csv")
hOri = hOri.drop(hOri.index[10000:])
hOri = hOri.drop(hOri.index[:5000])
print(hOri.size)

# hOri.to_csv("horseOriSmoothTrim.csv", header=False, index=False)