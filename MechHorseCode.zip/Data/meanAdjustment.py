import pandas as pd
import numpy as np
from requests import head

def mean_adj(x, mean_yaw, mean_roll, mean_pitch):
    x.iloc[0] -= mean_yaw
    x.iloc[1] -= mean_roll
    x.iloc[2] -= mean_pitch



def main():
    df = pd.read_csv('trimmed\horseOriSmoothTrim.csv', header = None)
    mean_yaw = df[0].mean(axis=0)
    mean_roll = df[1].mean(axis=0)
    mean_pitch = df[2].mean(axis=0)

    df.apply(lambda x: mean_adj(x, mean_yaw, mean_roll, mean_pitch), axis = 1)
    df.to_csv('trimmed\horseOriSmoothTrimAvg.csv',index=False, header=False)
    print('done')



if __name__ == "__main__":
    main()

