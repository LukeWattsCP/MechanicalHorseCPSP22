import csv
import math
import pandas as pd
import numpy as np

r1 = 2.5
r2 = -2.5
la1 = 40
la2 = 40

lb = 17.375
le = 8.5
lc = 3
ld = 36.25
lp = 15

ll = 24.25
lh = 10
lw = 6.75

def main():
    pred_angles = np.zeros((5000,6))
    df = pd.read_csv('trimmed\horseOriSmoothTrim.csv', header = None)
    # dp = df.iloc[0]
    

    # lp_i = lp * math.cos(yaw)
    # lp_j = lp * math.cos(pitch)
    # frame_i = -1 * (-1*lp_i + lb)
    # frame_j = lp_j - lc + ld

    j = 0


    for index, row in df.iterrows():
        yaw = math.radians(row.iloc[0]) # i hat
        roll = math.radians(row.iloc[1]) # k hat
        pitch = math.radians(row.iloc[2]) # j hat
        lp_k = lp * math.cos(roll)
        frame_k = -1 * (lp_k + le)
        i = 0
        guessed_pairs = np.zeros((129600,4))
        for theta1 in range(360):
            for theta2 in range(360):
                theta1rads = math.radians(theta1)
                theta2rads = math.radians(theta2)
                arm_k = r1*math.cos(theta1rads) - r2*math.cos(theta2rads) + 2*ll*math.cos(yaw) + 2*lh*math.cos(roll) - 2*lw*math.sin(yaw)
                k_err = math.fabs(((frame_k - arm_k) / frame_k) * 100)

                t1 = math.degrees(theta1rads)
                t2 = math.degrees(theta2rads)

                guessed_pairs[i][0] = theta1
                guessed_pairs[i][1] = theta2
                guessed_pairs[i][2] = k_err
                i += 1
                j += 1
        # print(guessed_pairs)
        guessed_pairs = guessed_pairs[guessed_pairs[:, 2].argsort()]
        # print(guessed_pairs)
        pred_angles[index][0] = guessed_pairs[0][0]
        pred_angles[index][1] = guessed_pairs[0][1]
        pred_angles[index][2] = guessed_pairs[0][2]
        pred_angles[index][3] = guessed_pairs[1][0]
        pred_angles[index][4] = guessed_pairs[1][1]
        pred_angles[index][5] = guessed_pairs[1][2]

    angles_df = pd.DataFrame(pred_angles, columns = ['theta1A','theta2A','thetaErrA','theta1B','theta2B','thetaErrB'])
    angles_df.to_csv('bruteforce2.csv', index = False, header = False)
   

        

   



    # arm_i = 2*(ll*math.sin(pitch) - ll*math.sin(yaw)) - 2*lh*math.cos(pitch) - 2*lw*math.cos(yaw) 
    # arm_j = (2*ll*math.cos(pitch) - 2*(lh*math.sin(pitch) + lh*math.sin(roll))) + r1*math.sin(theta1) # + r1*cos(theta_g1) + r2*cos(theta_g2) + la1 + la2
    
    # r2_j = frame_j - arm_j # = r2*math.cos(prev_theta2)
    # theta2 = math.asin(r2_j/r2)

if __name__ == "__main__":
    main()
